#include <iostream>
#include <string>

// Global variable representing player's health
int playerHealth = 100;

// Function to print player's status
void displayStatus() {
    std::cout << "Player's Health: " << playerHealth << std::endl;
}

// Overloaded function to attack different types of monsters
int attackMonster(std::string monsterType) {
    if (monsterType == "Zombie") {
        return 5;
    } else if (monsterType == "Vampire") {
        return 10;
    }
    return 0;  // Default damage
}

// Overloaded function with default argument for monster strength
int attackMonster(std::string monsterType, int strengthModifier) {
    return attackMonster(monsterType) + strengthModifier;
}

// Game loop function
void gameLoop() {
    std::string choice;
    while (playerHealth > 0) {
        std::cout << "A wild Zombie appears!\n";
        std::cout << "Do you want to (A)ttack, (R)un, or (Q)uit? ";
        std::cin >> choice;

        if (choice == "A" || choice == "a") {
            playerHealth -= attackMonster("Zombie");
            displayStatus();
        } else if (choice == "R" || choice == "r") {
            playerHealth -= attackMonster("Zombie", 2);  // Zombie gets a bonus attack
            displayStatus();
        } else if (choice == "Q" || choice == "q") {
            std::cout << "You decided to quit the game.\n";
            break;
        } else {
            std::cout << "Invalid choice!\n";
        }
    }

    if (playerHealth <= 0) {
        std::cout << "You were defeated by the monsters!\n";
    }
}

int main() {
    std::cout << "Welcome to the Monster Fighting Game!\n";
    displayStatus();
    gameLoop();
    return 0;
}
